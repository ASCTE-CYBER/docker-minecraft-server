kill @s
