execute as @s[type=player,gamemode=!creative,gamemode=!spectator] run function wasd.lib:damage/player/3
execute as @s[type=#wasd.tags:mobs] run function wasd.lib:damage/mob/3